//ex 1

SET SERVEROUTPUT ON;

DECLARE 
    nome VARCHAR2(100);
BEGIN
    nome:='mary';
    dbms_output.put_line(nome);  
END;

//ex 2

SET SERVEROUTPUT ON;

DECLARE

    VL1 NUMBER;
    VL2 NUMBER;
    VL3 NUMBER;
    TOTAL NUMBER;
    
BEGIN
    VL1:= 1;
    VL2:= 2;
    VL3:= 3;
    TOTAL:= VL1+VL2+VL3;
    dbms_output.put_line('a soma eh: ' || total);
END;
    
//ex 3

SET SERVEROUTPUT ON;

DECLARE 
    VLR INT;
    ANT INT;
    SUC INT;
    
BEGIN
    VLR:= 10;
    ANT:= VLR-1;
    SUC:= VLR+1;
    
    dbms_output.put_line('o valor eh: ' || VLR);
    dbms_output.put_line('o antecessor eh: ' || ANT);
    dbms_output.put_line('o sucessor eh: ' || SUC);
    
END;

// ex 4

DECLARE
    MEU_SALARIO NUMBER;
    QTD NUMBER;
    
BEGIN
    MEU_SALARIO:=4500;
    QTD:= MEU_SALARIO/1412;
    dbms_output.put_line('a quantidade de salarios eh de: ' || QTD);
    

END;

// ex 5

DECLARE
    CP1 NUMERIC:=10;
    CP2 NUMERIC:=8;
    CP3 NUMERIC:=5;
    MEDIA NUMERIC;
    
BEGIN
    MEDIA:= (CP1+CP2+CP3/3);
    dbms_output.put_line('a media eh de: ' || MEDIA);
    
END;

// ex 6

DECLARE
    MEU_SALARIO NUMBER;
    
BEGIN
    MEU_SALARIO:=4500;
    dbms_output.put_line(MEU_SALARIO*0.05);
    dbms_output.put_line(MEU_SALARIO*1.05);
    dbms_output.put_line(MEU_SALARIO);
END;